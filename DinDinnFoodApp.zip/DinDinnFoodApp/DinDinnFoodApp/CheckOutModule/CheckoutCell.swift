//
//  CheckoutCell.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/29/20.
//

import UIKit

class CheckoutCell: UITableViewCell {
    // MARK: - Outlets
    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var itemPrice: UILabel!
    @IBOutlet weak var removeButton: UIButtonDesignable!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
