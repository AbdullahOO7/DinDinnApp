//
//  CheckoutDatasource.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/29/20.
//

import Foundation
import ObjectMapper
import Moya

extension CheckoutViewController: UITableViewDelegate, UITableViewDataSource {
    // MARK: - Tableview datasource and delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return checkoutDataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UINib.init(nibName: "CheckoutItem", bundle: nil), forCellReuseIdentifier: "CheckoutItemCell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "CheckoutItemCell") as! CheckoutCell
        
        if (self.checkoutDataSource[indexPath.row].serviceType == "Pizza") {
            cell.itemImageView.image = UIImage(named: "Pizza\(String(describing: self.checkoutDataSource[indexPath.row].image!))")
        } else {
            cell.itemImageView.image = UIImage(named: "Sushi\(String(describing: self.checkoutDataSource[indexPath.row].image!))")
        }
        
        cell.itemPrice.text = "\(self.checkoutDataSource[indexPath.row].price!) usd"
        cell.itemName.text = self.checkoutDataSource[indexPath.row].name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return footerView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
}
