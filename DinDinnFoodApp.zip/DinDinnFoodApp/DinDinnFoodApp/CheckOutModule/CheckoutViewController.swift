//
//  CheckoutViewController.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/29/20.
//

import UIKit

class CheckoutViewController: UIViewController {
    // MARK: - Outlets
    @IBOutlet weak var cartTableView: UITableView!
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var totalBillValue: UILabel!
    
    // MARK: - Variables
    var checkoutDataSource = [FoodList]()
    var totalBill = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cartTableView.dataSource = self
        cartTableView.delegate = self
        cartTableView.alwaysBounceVertical = false
        cartTableView.separatorStyle = .none
        
        for i in 0..<checkoutDataSource.count {
            totalBill += checkoutDataSource[i].price
        }
        
        totalBillValue.text = "\(totalBill) usd"
        cartTableView.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
    }
    
    // MARK: - Actions
    
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    }
}
