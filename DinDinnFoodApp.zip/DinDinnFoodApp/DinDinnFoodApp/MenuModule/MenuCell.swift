//
//  FoodItemCell.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/29/20.
//

import UIKit

class MenuCell: UITableViewCell {
    var itemPriceButtonAction: ((UIButtonDesignable) -> Void)?
    
    // MARK: - Outlets
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var itemDescription: UILabel!
    @IBOutlet weak var itemQtyDescription: UILabel!
    @IBOutlet weak var itemPriceButton: UIButtonDesignable!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override func prepareForReuse() {
        //Reset content view width
        itemPriceButton.representedIndex = -1
    }
    
    @IBAction func itemPriceButtonTapped(_ sender: UIButtonDesignable) {
        self.itemPriceButtonAction?(sender)
    }
}
