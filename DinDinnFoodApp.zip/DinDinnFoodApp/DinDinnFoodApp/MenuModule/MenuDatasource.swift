//
//  HomeDatasource.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/29/20.
//

import Foundation
import ObjectMapper
import Moya

extension MenuViewController: UITableViewDelegate, UITableViewDataSource {
    // MARK: - Tableview Datasource and Delegates
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.currentServiceType == "Pizza" && self.pizzaDataSource != nil) {
            return self.pizzaDataSource.count
        } else if (self.currentServiceType == "Sushi" && self.sushiDataSource != nil) {
            return self.sushiDataSource.count
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UINib.init(nibName: "MenuItem", bundle: nil), forCellReuseIdentifier: "MenuItemCell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuItemCell") as! MenuCell
        cell.backgroundColor = .clear
        
        if (self.currentServiceType == "Pizza") {
            cell.itemName.text = self.pizzaDataSource[indexPath.row].name
            cell.itemImage.image = UIImage(named: "Pizza\(String(describing: self.pizzaDataSource[indexPath.row].image!))")
            cell.itemPriceButton.setTitle("\(String(describing: self.pizzaDataSource[indexPath.row].price!)) usd", for: .normal)
            cell.itemDescription.text = self.pizzaDataSource[indexPath.row].description
            cell.itemQtyDescription.text = self.pizzaDataSource[indexPath.row].qtyDescription
        } else if (self.currentServiceType == "Sushi") {
            cell.itemName.text = self.sushiDataSource[indexPath.row].name
            cell.itemImage.image = UIImage(named: "Sushi\(String(describing: self.sushiDataSource[indexPath.row].image!))")
            cell.itemPriceButton.setTitle("\(String(describing: self.sushiDataSource[indexPath.row].price!)) usd", for: .normal)
            cell.itemDescription.text = self.sushiDataSource[indexPath.row].description
            cell.itemQtyDescription.text = self.sushiDataSource[indexPath.row].qtyDescription
        }
        
        cell.itemPriceButton.representedIndex = indexPath.row
        cell.itemPriceButtonAction = { sender in
            UIView.animate(withDuration: 0.5, delay: 0.2, options: [.curveLinear, .allowAnimatedContent, .allowUserInteraction]) {
                cell.itemPriceButton.setTitle("Added +1", for: .normal)
                cell.itemPriceButton.backgroundColor = .green
            } completion: { (true) in
                if (self.currentServiceType == "Pizza") {
                    cell.itemPriceButton.setTitle("\(String(describing: self.pizzaDataSource[sender.representedIndex].price!)) usd", for: .normal)
                } else if (self.currentServiceType == "Sushi") {
                    cell.itemPriceButton.setTitle("\(String(describing: self.sushiDataSource[sender.representedIndex].price!)) usd", for: .normal)
                }
                
                cell.itemPriceButton.backgroundColor = .black
            }
        }
        
        cell.itemPriceButton.addTarget(self, action: #selector(itemTapped(sender:)), for: .touchUpInside)
        cell.itemPriceButton.tag = indexPath.row
        
        return cell
    }
    
    @objc func itemTapped(sender: UIButton){
        if (self.cartItemCounter.isHidden == true) {
            self.cartItemCounter.isHidden = false
        }
        
        var count = Int(self.cartItemCounter.text!)!
        count += 1
        self.cartItemCounter.text = "\(count)"
        
        if (self.currentServiceType == "Pizza") {
            let item = FoodList(Id: pizzaDataSource![sender.tag].id!, Name: pizzaDataSource![sender.tag].name!, Description: pizzaDataSource![sender.tag].description!, Qtydescription: pizzaDataSource![sender.tag].qtyDescription!, Price: pizzaDataSource![sender.tag].price!, Image: pizzaDataSource![sender.tag].image!, ServiceType: "Pizza")
            self.checkoutDataSource.insert(item, at: 0)
        } else {
            let item = FoodList(Id: sushiDataSource![sender.tag].id!, Name: sushiDataSource![sender.tag].name!, Description: sushiDataSource![sender.tag].description!, Qtydescription: sushiDataSource![sender.tag].qtyDescription!, Price: sushiDataSource![sender.tag].price!, Image: sushiDataSource![sender.tag].image!, ServiceType: "Sushi")
            self.checkoutDataSource.insert(item, at: 0)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return menuHeaderView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let yOffset = scrollView.contentOffset.y

        if yOffset >= 50 {
            cartButton.isHidden = false
            
            if (cartItemCounter.text != "0") {
                cartItemCounter.isHidden = false
            }
        } else {
            cartButton.isHidden = true
            cartItemCounter.isHidden = true
        }
    }
    
    // MARK: - API
    func fetchPizzaList() {
        NetworkAdapter.request(target: .pizzaList, success: { (response) in
            do {
                let json = try? JSONSerialization.jsonObject(with: response.data, options: [])
                self.pizzaDataSource = Mapper<FoodList>().mapArray(JSONObject: json)
                self.menuTableView.reloadData()
            } catch {
                // can't parse data, show error
            }
        }, error: { (error) in
            // show error from server
        }, failure: { (error) in
            let str = """
                [
                  {
                    \"id\": 1,
                    \"name\": \"Deluxe\",
                    \"description\": \"Chicken, Ham, Pepperoni, Tomato sauce, Spicy chorizo and Mozarelia\",
                    \"qty_description\": \"150 grams, 30 cm\",
                    \"price\": 45,
                    \"image\": 1,
                    \"service_type\": \"Pizza\",
                  },
                  {
                    \"id\": 2,
                    \"name\": \"Hawaiian\",
                    \"description\": \"Chicken, Mozarelia, Pineapple, Domino's sauce\",
                    \"qty_description\": \"200 grams, 35 cm\",
                    \"price\": 55,
                    \"image\": 2,
                    \"service_type\": \"Pizza\",
                  },
                  {
                    \"id\": 3,
                    \"name\": \"Pepperoni\",
                    \"description\": \"Mozarelia, Pepperoni, Tomatoes, BBQ sauce\",
                    \"qty_description\": \"170 grams, 32 cm\",
                    \"price\": 50,
                    \"image\": 3,
                    \"service_type\": \"Pizza\",
                  },
                  {
                    \"id\": 4,
                    \"name\": \"Neapolitan\",
                    \"description\": \"Tomatoes, Garlic, Oregano, and Extra virgin olive oil\",
                    \"qty_description\": \"250 grams, 45 cm\",
                    \"price\": 65,
                    \"image\": 4,
                    \"service_type\": \"Pizza\",
                  }
                ]
                """
            
            let data = str.data(using: .utf8)!
            do {
                if let jsonArray = try JSONSerialization.jsonObject(with: data, options : .allowFragments) as? [Dictionary<String,Any>]
                {
                    self.pizzaDataSource = Mapper<FoodList>().mapArray(JSONObject: jsonArray)
                    self.menuTableView.reloadData()
                    print(jsonArray) // use the json here
                } else {
                    print("bad json")
                }
            } catch let error as NSError {
                print(error)
            }
        })
    }
    
    func fetchSushiList() {
        NetworkAdapter.request(target: .sushiList, success: { (response) in
            do {
                let json = try? JSONSerialization.jsonObject(with: response.data, options: [])
                self.sushiDataSource = Mapper<FoodList>().mapArray(JSONObject: json)
                self.menuTableView.reloadData()
            } catch {
                // can't parse data, show error
            }
        }, error: { (error) in
            // show error from server
        }, failure: { (error) in
            let str =  """
                [
                  {
                    \"id\": 1,
                    \"name\": \"The egoist\",
                    \"description\": \"Fila classic, maci spice-salmon, two sushui salmon, two guangana salami\",
                    \"qty_description\": \"450 grams, 25 pieces\",
                    \"price\": 45,
                    \"image\": 1,
                    \"service_type\": \"Sushi\",
                  },
                  {
                    \"id\": 2,
                    \"name\": \"California\",
                    \"description\": \"California with salmon gril, fila with salmon, fila with lollo-rossa, futomaki perch cheess, maki spicy salmon.\",
                    \"qty_description\": \"930 grams, 38 pieces\",
                    \"price\": 65,
                    \"image\": 2,
                    \"service_type\": \"Sushi\",
                  },
                  {
                    \"id\": 3,
                    \"name\": \"The boist sushi\",
                    \"description\": \"Fila classic, maci spice-salmon, two sushui salmon, two guangana salami\",
                    \"qty_description\": \"400 grams, 18 pieces\",
                    \"price\": 30,
                    \"image\": 3,
                    \"service_type\": \"Sushi\",
                  },
                  {
                    \"id\": 4,
                    \"name\": \"California sushi\",
                    \"description\": \"California with salmon gril, fila with salmon, fila with lollo-rossa, futomaki perch cheess, maki spicy salmon.\",
                    \"qty_description\": \"575 grams, 20 pieces\",
                    \"price\": 35,
                    \"image\": 4,
                    \"service_type\": \"Sushi\",
                  }
                ]
                """
            
            let data = str.data(using: .utf8)!
            do {
                if let jsonArray = try JSONSerialization.jsonObject(with: data, options : .allowFragments) as? [Dictionary<String,Any>]
                {
                    self.sushiDataSource = Mapper<FoodList>().mapArray(JSONObject: jsonArray)
                    self.menuTableView.reloadData()
                    print(jsonArray) // use the json here
                } else {
                    print("bad json")
                }
            } catch let error as NSError {
                print(error)
            }
        })
    }
}
