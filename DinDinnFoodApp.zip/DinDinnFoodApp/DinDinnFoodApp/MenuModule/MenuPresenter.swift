//
//  MenuPresenter.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/30/20.
//

import UIKit

extension MenuViewController {
    // MARK: - Presenter Functions
    
    func animateImageView() {
        CATransaction.begin()
        CATransaction.setAnimationDuration(animationDuration)
        
        CATransaction.setCompletionBlock {
            DispatchQueue.main.asyncAfter(deadline: .now() + self.switchingInterval) {[weak self] in
                self?.animateImageView()
            }
        }
        
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromRight
        promoImageView.layer.add(transition, forKey: kCATransition)
        
        if promoImages.count != 0 {
            promoImageView.image = promoImages[index]
        }
        
        CATransaction.commit()
        index = index < promoImages.count - 1 ? index + 1 : 0
        pageControl.currentPage = index
    }
    
    func changeButtonTitleColor(name: String) {
        self.pizzaButton.setTitleColor(.lightGray, for: .normal)
        self.sushiButton.setTitleColor(.lightGray, for: .normal)
        self.drinksButton.setTitleColor(.lightGray, for: .normal)
        
        if (name == "Pizza") {
            self.pizzaButton.setTitleColor(.black, for: .normal)
        } else if (name == "Sushi") {
            self.sushiButton.setTitleColor(.black, for: .normal)
        } else {
            self.drinksButton.setTitleColor(.black, for: .normal)
        }
    }
}

