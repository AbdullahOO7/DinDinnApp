//
//  MenuViewController.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/28/20.
//

import UIKit
import Moya

class MenuViewController: UIViewController {
    // MARK: - Outlets
    @IBOutlet weak var menuTableView: UITableView!
    @IBOutlet weak var menuHeaderView: UIView!
    @IBOutlet weak var menuServiceTypesStackview: UIStackView!
    @IBOutlet weak var pizzaButton: UIButton!
    @IBOutlet weak var sushiButton: UIButton!
    @IBOutlet weak var drinksButton: UIButton!
    @IBOutlet weak var spicyFilterButton: UIButtonDesignable!
    @IBOutlet weak var veganFilterButton: UIButtonDesignable!
    @IBOutlet weak var promoImageView: UIImageView!
    @IBOutlet weak var cartButton: UIButtonDesignable!
    @IBOutlet weak var cartItemCounter: UILableDesignable!
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    // MARK: - Variables
    let promoImages = [UIImage(named: "Discount1")!, UIImage(named: "Discount2")!, UIImage(named: "Discount3")!]
    var index = 0
    let animationDuration: TimeInterval = 0.25
    let switchingInterval: TimeInterval = 3
    var transition = CATransition()
    var pizzaDataSource: [FoodList]!
    var sushiDataSource: [FoodList]!
    var checkoutDataSource = [FoodList]()
    var currentServiceType = "Pizza"
    let globals = Globals()
    var provider: MoyaProvider<MyService>!
    
    let endpointClosure = { (target: MyService) -> Endpoint in
        return Endpoint(url: URL(target: target).absoluteString, sampleResponseClosure: {.networkResponse(200, target.sampleData)}, method: target.method, task: target.task, httpHeaderFields: target.headers)
    }
    
    let failureEndpointClosure = { (target: MyService) -> Endpoint in
        let sampleResponseClosure = { () -> (EndpointSampleResponse) in
            return .networkResponse(200, target.sampleData)
        }
        
        return Endpoint(url: URL(target: target).absoluteString, sampleResponseClosure: sampleResponseClosure, method: target.method, task: target.task, httpHeaderFields: target.headers)
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated)
        
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool){
        super.viewWillDisappear(animated)
        
        self.navigationController?.isNavigationBarHidden = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        promoImageView.image = promoImages[index]
        animateImageView()
        index += 1
        
        menuTableView.alwaysBounceVertical = false
        menuTableView.separatorStyle = .none
        
        self.fetchPizzaList()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
    }
    
    // MARK: - Actions
    
    @objc func handleGesture(gesture: UISwipeGestureRecognizer) -> Void {
        if gesture.direction == .right {
            print("Swipe Right")
            
            if (menuServiceTypesStackview.arrangedSubviews[0] == self.pizzaButton) {
                menuServiceTypesStackview.insertArrangedSubview(self.sushiButton, at: 0)
                currentServiceType = "Sushi"
                self.fetchSushiList()
            } else if (menuServiceTypesStackview.arrangedSubviews[0] == self.sushiButton) {
                menuServiceTypesStackview.insertArrangedSubview(self.drinksButton, at: 0)
                currentServiceType = "Drinks"
                menuTableView.reloadData()
                globals.showAlert("Drinks Alert", message: "Drinks are not available right now.", presentationView: self)
            } else if (menuServiceTypesStackview.arrangedSubviews[0] == self.drinksButton) {
                menuServiceTypesStackview.insertArrangedSubview(self.pizzaButton, at: 0)
                currentServiceType = "Pizza"
                self.fetchPizzaList()
            }
        }
        else if gesture.direction == .left {
            print("Swipe Left")
            
            if (menuServiceTypesStackview.arrangedSubviews[0] == self.pizzaButton) {
                menuServiceTypesStackview.insertArrangedSubview(self.sushiButton, at: 0)
                currentServiceType = "Sushi"
                self.fetchSushiList()
            } else if (menuServiceTypesStackview.arrangedSubviews[0] == self.sushiButton) {
                menuServiceTypesStackview.insertArrangedSubview(self.drinksButton, at: 0)
                currentServiceType = "Drinks"
                menuTableView.reloadData()
                globals.showAlert("Drinks Alert", message: "Drinks are not available right now.", presentationView: self)
            } else if (menuServiceTypesStackview.arrangedSubviews[0] == self.drinksButton) {
                menuServiceTypesStackview.insertArrangedSubview(self.pizzaButton, at: 0)
                currentServiceType = "Pizza"
                self.fetchPizzaList()
            }
        }
        
        changeButtonTitleColor(name: currentServiceType)
    }
    
    @IBAction func menuServiceTypeTapped(_ sender: UIButton) {
        menuServiceTypesStackview.addArrangedSubview(self.menuServiceTypesStackview.subviews[0])
        
        if (sender.tag == 1) {
            menuServiceTypesStackview.insertArrangedSubview(self.pizzaButton, at: 0)
            currentServiceType = "Pizza"
            self.fetchPizzaList()
        } else if (sender.tag == 2) {
            menuServiceTypesStackview.insertArrangedSubview(self.sushiButton, at: 0)
            currentServiceType = "Sushi"
            self.fetchSushiList()
        } else if (sender.tag == 3) {
            menuServiceTypesStackview.insertArrangedSubview(self.drinksButton, at: 0)
            currentServiceType = "Drinks"
            menuTableView.reloadData()
            globals.showAlert("Drinks Alert", message: "Drinks are not available right now.", presentationView: self)
        }
        
        changeButtonTitleColor(name: currentServiceType)
    }
    
    @IBAction func cartTapped(_ sender: UIButtonDesignable) {
        let count = Int(self.cartItemCounter.text!)!
        
        if (count > 0) {
            self.performSegue(withIdentifier: "CartSegue", sender: self)
        }
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "CartSegue" {
            if let destination = segue.destination as? CheckoutViewController {
                destination.checkoutDataSource = self.checkoutDataSource
            }
        }
    }
}
