//
//  FoodList.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/29/20.
//

import Foundation
import ObjectMapper

class FoodList: Mappable {
    var id: Int!
    var name: String!
    var description: String!
    var qtyDescription: String!
    var price: Int!
    var image: Int!
    var serviceType: String!
    
    required init?(map: Map) {

    }

    init(Id: Int, Name: String, Description: String, Qtydescription: String, Price: Int, Image: Int, ServiceType: String) {
        self.id = Id
        self.name = Name
        self.description = Description
        self.qtyDescription = Qtydescription
        self.price = Price
        self.image = Image
        self.serviceType = ServiceType
    }
    
    // Mappable
    func mapping(map: Map) {
        id                      <- map["id"]
        name                    <- map["name"]
        description             <- map["description"]
        qtyDescription          <- map["qty_description"]
        price                   <- map["price"]
        image                   <- map["image"]
        serviceType             <- map["service_type"]
    }
}
