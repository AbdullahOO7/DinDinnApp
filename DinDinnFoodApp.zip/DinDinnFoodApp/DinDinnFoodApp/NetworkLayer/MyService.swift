//
//  MyService.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/28/20.
//

import Moya

enum MyService {
    case serviceTypes
    case pizzaList
    case sushiList
}

// MARK: - TargetType Protocol Implementation
extension MyService: TargetType {
    var baseURL: URL {
        return URL(string: "https://api.DinDinn.com")!
    }
    
    var path: String {
        switch self {
        case .serviceTypes:
            return "/serviceTypes"
        case .pizzaList:
            return "/pizzaList"
        case .sushiList:
            return "/sushiList"
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .serviceTypes, .pizzaList, .sushiList:
            return .get
        }
    }
    
    var task: Task {
        switch self {
        case .serviceTypes, .pizzaList, .sushiList:
            return .requestPlain
        }
    }
    
    var sampleData: Data {
        switch self {
        case .serviceTypes:
            return """
                [
                  {
                    \"id\": 1,
                    \"name\": \"Pizza\",
                  },
                  {
                    \"id\": 2,
                    \"name\": \"Sushi\",
                  },
                  {
                    \"id\": 3,
                    \"name\": \"Drinks\",
                  }
                ]
                """.utf8Encoded
        case .pizzaList:
            return """
                [
                  {
                    \"id\": 1,
                    \"name\": \"Deluxe\",
                    \"description\": \"Chicken, Ham, Pepperoni, Tomato sauce, Spicy chorizo and Mozarelia\",
                    \"qty_description\": \"150 grams, 30 cm\",
                    \"price\": 45,
                    \"image\": 1,
                  },
                  {
                    \"id\": 2,
                    \"name\": \"Hawaiian\",
                    \"description\": \"Chicken, Mozarelia, Pineapple, Domino's sauce\",
                    \"qty_description\": \"200 grams, 35 cm\",
                    \"price\": 55,
                    \"image\": 2,
                  },
                  {
                    \"id\": 3,
                    \"name\": \"Pepperoni\",
                    \"description\": \"Mozarelia, Pepperoni, Tomatoes, BBQ sauce\",
                    \"qty_description\": \"170 grams, 32 cm\",
                    \"price\": 50,
                    \"image\": 3,
                  },
                  {
                    \"id\": 4,
                    \"name\": \"Neapolitan\",
                    \"description\": \"Tomatoes, Garlic, Oregano, and Extra virgin olive oil\",
                    \"qty_description\": \"250 grams, 45 cm\",
                    \"price\": 65,
                    \"image\": 4,
                  }
                ]
                """.utf8Encoded
        case .sushiList:
            return """
                [
                  {
                    \"id\": 1,
                    \"name\": \"The egoist\",
                    \"description\": \"Fila classic, maci spice-salmon, two sushui salmon, two guangana salami\",
                    \"qty_description\": \"450 grams, 25 pieces\",
                    \"price\": 45,
                    \"image\": 1,
                  },
                  {
                    \"id\": 2,
                    \"name\": \"California\",
                    \"description\": \"California with salmon gril, fila with salmon, fila with lollo-rossa, futomaki perch cheess, maki spicy salmon.\",
                    \"qty_description\": \"930 grams, 38 pieces\",
                    \"price\": 65,
                    \"image\": 2,
                  },
                  {
                    \"id\": 3,
                    \"name\": \"The boist sushi\",
                    \"description\": \"Fila classic, maci spice-salmon, two sushui salmon, two guangana salami\",
                    \"qty_description\": \"400 grams, 18 pieces\",
                    \"price\": 30,
                    \"image\": 3,
                  },
                  {
                    \"id\": 4,
                    \"name\": \"California sushi\",
                    \"description\": \"California with salmon gril, fila with salmon, fila with lollo-rossa, futomaki perch cheess, maki spicy salmon.\",
                    \"qty_description\": \"575 grams, 20 pieces\",
                    \"price\": 35,
                    \"image\": 4,
                  }
                ]
                """.utf8Encoded
        }
    }
    
    var headers: [String: String]? {
        return ["Content-type": "application/json"]
    }
}

// MARK: - Helpers
private extension String {
    var urlEscaped: String {
        return addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    }

    var utf8Encoded: Data {
        return data(using: .utf8)!
    }
}
