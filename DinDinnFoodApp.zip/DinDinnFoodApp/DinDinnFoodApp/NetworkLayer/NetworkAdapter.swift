//
//  NetworkAdapter.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/30/20.
//

import Foundation
import Moya

struct NetworkAdapter {
    static let provider = MoyaProvider<MyService>()
    
    static func request(target: MyService, success successCallback: @escaping (Response) -> Void, error errorCallback: @escaping (Swift.Error) -> Void, failure failureCallback: @escaping (MoyaError) -> Void) {
        
        provider.request(target) { (result) in
            switch result {
            case .success(let response):
                if response.statusCode >= 200 && response.statusCode <= 300 {
                    successCallback(response)
                } else {
                   let error = NSError(domain:"com.DinDinnAssignment.DinDinnFoodApp", code:0, userInfo:[NSLocalizedDescriptionKey: "Parsing Error"])
                    errorCallback(error)
                }
            case .failure(let error):
                failureCallback(error)
            }
        }
    }
}
