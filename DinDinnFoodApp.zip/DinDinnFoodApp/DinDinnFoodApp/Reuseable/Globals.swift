//
//  Globals.swift
//  DinDinnFoodApp
//
//  Created by Muhammad Abdullah on 11/29/20.
//

import UIKit

class Globals {
    func showAlert(_ title: String, message: String, presentationView: UIViewController) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        presentationView.present(alertController, animated: true, completion: nil)
    }
}
